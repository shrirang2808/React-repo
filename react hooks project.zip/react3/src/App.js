import { useState } from "react";
import "./App.css";
import ButtonCounter from "./components/ButtonCounter";

function App() {
  const [totalSum, setTotalSum] = useState(0);
  const [resetSignal, setResetSignal] = useState(false);
  const handleButtonClick = () => {
    setTotalSum(prev => prev+1);
  }
  const handleReset = () => {
    setTotalSum(0);
    setResetSignal(true);
  };
  return (
    <div className="container mt-5">
      <div className="row">
        {[...Array(9)].map((_, index) => (
          <div className="col-4 mb-3" key={index}>
            <ButtonCounter buttonNumber={index + 1} handleButtonClick = {handleButtonClick} resetSignal={resetSignal} />
          </div>
        ))}
      </div>

      <div className="text-center">
        <div>Total sum: {totalSum}</div>
        <button className="btn btn-danger mt-3" onClick={handleReset}>
          Reset All
        </button>
      </div>
    </div>
  );
}

export default App;
