import React, { useEffect, useState } from "react";
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import '../Style/ButtonCounter.css'

const ButtonCounter = ({buttonNumber, handleButtonClick, resetSignal}) => {
  const [hitCount, setCount] = useState(0);
  function handleClick(){
    setCount(prev => prev + 1);
    handleButtonClick();
  }
  useEffect(()=>{
    if (resetSignal) {
      setCount(0);
    }
  }, [resetSignal])
  return (
    <div>
      <div className="card">
        <div className="click-display">
          Clicks count: {hitCount}
        </div>
        <hr />
        <button className="count-btn btn btn-primary btn-sm" onClick={handleClick}>
          {buttonNumber}
        </button>
        <hr />
      </div>
    </div>
  );
};

export default ButtonCounter;
