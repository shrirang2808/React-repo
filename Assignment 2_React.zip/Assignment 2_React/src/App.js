import {useState} from 'react'
import * as XLSX from 'xlsx'
import './App.css';

function App() {
  const [data, setData] = useState([]);
  const handleFileUpload = (e) =>{
    const reader = new FileReader();
    reader.readAsBinaryString(e.target.files[0]);
    reader.onload = (e) =>{
      const data = e.target.result;
      const workbook = XLSX.read(data, {type: "binary"});
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const parsedData = XLSX.utils.sheet_to_json(sheet);
      setData(parsedData);
    }
  }
  const handleExport = () => {
    var wb = XLSX.utils.book_new(),
    ws = XLSX.utils.json_to_sheet(data);
    XLSX.utils.book_append_sheet(wb, ws, "MySheet1");
    XLSX.writeFile(wb, "MyExcel.xlsx");
  }
  return (
    <div className="App">
      <input type="file" accept='.xlsx, .xls' onChange={handleFileUpload}/>
      <button onClick={handleExport}>Export data</button>
      {data.length>0 && <table border={'1px'}>
        <tr>
          <th>Id</th>
          {Object.keys(data[0])?.map((key)=>(
            <th key={key}>{key}</th>
          ))}
        </tr>
        {data?.map((row, index)=>
          <tr key={index}>
          <td>{index+1}</td>
          {Object.values(row).map((value, index)=>
            <td key={index}>
             <div className={index===3 && (value>=8 ? 'ratingGreen' : (value>=5 && value<=7.9 )?'ratingOrange' : 'ratingRed')}>{value}</div> 
            </td>
          )
          }
        </tr>)}
      </table>}
    </div>
  );
}

export default App;
