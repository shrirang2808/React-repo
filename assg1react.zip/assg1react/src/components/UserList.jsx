import React from 'react'
import '../style/userList.css'

const UserList = (prop) => {
  return (
    <div className='userList'>
        <h2>User List</h2>
        <ul>
            {
                prop.arr.map((item)=>
                    <li key={item.id}>
                        <div>{item.name}</div>
                        <div>{item.email}</div>
                        <div>{item.age}</div>
                    </li>
                )
            }
        </ul>
    </div>
  )
}

export default UserList