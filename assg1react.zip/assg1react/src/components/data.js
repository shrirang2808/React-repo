export const arr = [
    {
        id: 1,
        name: 'John Doe',
        email: 'john.doe@example.com',
        age: 34,
        },
        {
        id: 2,
        name: 'Jane Smith',
        email: 'jane.smith@example.com',
        age: 28,
        },
        {
        id: 3,
        name: 'Harry Johnson',
        email: 'harry.johnson@example.com',
        age: 46,
        },
        {
        id: 4,
        name: 'Emma Wilson',
        email: 'emma.wilson@example.com',
        age: 38,
        },
]