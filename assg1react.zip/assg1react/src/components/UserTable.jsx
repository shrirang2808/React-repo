import React from 'react'
import '../style/userTable.css'

const UserTable = ({ arr }) => {
    console.log(arr)
    return (
        <div className='userTable'>
            <h2>User table</h2>
            <table border={'1px'}>
                <tr>
                    <th>
                        name
                    </th>
                    <th>
                        email
                    </th>
                    <th>
                        age
                    </th>
                </tr>
                {arr.map((item) => 
                    <tr key={item.id}>
                        <td>
                            {item.name}
                        </td>
                        <td>
                            {item.email}
                        </td>
                        <td>
                            {item.age}
                        </td>
                    </tr>
                )}
            </table>
        </div>
    )
}

export default UserTable